```bash
sudo apt-get install -y python3.10-venv
python3 -m pip install --upgrade build
python3 -m build
```
