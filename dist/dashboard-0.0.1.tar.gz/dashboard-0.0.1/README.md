# e-Ink Display

This is a small project to experiment with e-Ink displays